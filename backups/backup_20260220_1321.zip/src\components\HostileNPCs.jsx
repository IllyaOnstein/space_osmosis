import React, { useRef, useState, useCallback, useEffect, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { RigidBody } from '@react-three/rapier';
import { Trail } from '@react-three/drei';
import * as THREE from 'three';
import { useGame } from '../context/GameContext';

const NPC_COUNT = 6;
const MIN_SPAWN_DIST = 40;
const MAX_SPAWN_DIST = 100;
const TRACKING_RANGE = 45;

const randomPosInShell = (center, innerR = MIN_SPAWN_DIST, outerR = MAX_SPAWN_DIST) => {
    const theta = Math.random() * 2 * Math.PI;
    const phi = Math.acos(2 * Math.random() - 1);
    const r = innerR + Math.random() * (outerR - innerR);
    return [
        center.x + r * Math.sin(phi) * Math.cos(theta),
        center.y + r * Math.sin(phi) * Math.sin(theta),
        center.z + r * Math.cos(phi)
    ];
};

const HostileNPC = ({ id, initialLevel, initialPosition, onDestroy }) => {
    const rigidBody = useRef();
    const meshRef = useRef();
    const destroyedRef = useRef(false);
    const lastLaserHitRef = useRef(null);
    const { playerPosRef, takeDamage, addExperience } = useGame();

    const level = initialLevel;
    const radius = 0.5 + (level - 1) * 0.2;
    const speed = 5 + level * 2;

    // 稳定的初始位置 — 用 useMemo 保证不会因重渲染而改变
    const stablePosition = useMemo(() => initialPosition, []);

    useFrame((state, delta) => {
        if (!rigidBody.current || !playerPosRef.current || destroyedRef.current) return;

        const translation = rigidBody.current.translation();
        const pos = new THREE.Vector3(translation.x, translation.y, translation.z);
        const pPos = new THREE.Vector3(playerPosRef.current.x, playerPosRef.current.y, playerPosRef.current.z);
        const dist = pos.distanceTo(pPos);

        // 上报位置给雷达
        if (!window.npcPositions) window.npcPositions = {};
        window.npcPositions[id] = { x: translation.x, y: translation.y, z: translation.z };

        // --- 追踪与移动逻辑 ---
        if (dist < TRACKING_RANGE) {
            const dir = pPos.clone().sub(pos).normalize();
            rigidBody.current.applyImpulse({
                x: dir.x * speed * delta * 2,
                y: dir.y * speed * delta * 2,
                z: dir.z * speed * delta * 2
            }, true);
        } else {
            const noise = state.clock.getElapsedTime() + id * 17.31;
            rigidBody.current.applyImpulse({
                x: Math.sin(noise) * 2 * delta,
                y: Math.cos(noise * 0.8) * 2 * delta,
                z: Math.sin(noise * 1.2) * 2 * delta
            }, true);
        }

        // 限制速度
        const vel = rigidBody.current.linvel();
        const currentSpeed = Math.sqrt(vel.x ** 2 + vel.y ** 2 + vel.z ** 2);
        if (currentSpeed > speed) {
            const ratio = speed / currentSpeed;
            rigidBody.current.setLinvel({
                x: vel.x * ratio,
                y: vel.y * ratio,
                z: vel.z * ratio
            }, true);
        }

        // --- 激光击中检测（带去重！） ---
        if (window.laserHit && window.laserHit.time !== lastLaserHitRef.current) {
            const hitPt = window.laserHit.point;
            const dHit = pos.distanceTo(new THREE.Vector3(hitPt.x, hitPt.y, hitPt.z));
            lastLaserHitRef.current = window.laserHit.time;
            if (dHit < radius + 1.5) {
                doDestroy();
                return;
            }
        }

        // --- 黑洞吸引 ---
        if (window.blackHoleActive) {
            const bh = window.blackHoleActive;
            const dBH = pos.distanceTo(new THREE.Vector3(bh.x, bh.y, bh.z));
            if (dBH < bh.radius) {
                if (dBH < 3) {
                    doDestroy();
                    return;
                } else {
                    const pull = 40 / Math.max(dBH, 1);
                    const dir = new THREE.Vector3(bh.x - pos.x, bh.y - pos.y, bh.z - pos.z).normalize();
                    rigidBody.current.setLinvel({
                        x: dir.x * pull,
                        y: dir.y * pull,
                        z: dir.z * pull
                    }, true);
                }
            }
        }

        // --- 范围外回收（不触发销毁，直接传送回来） ---
        if (dist > 180) {
            const newPos = randomPosInShell(playerPosRef.current);
            rigidBody.current.setTranslation({ x: newPos[0], y: newPos[1], z: newPos[2] }, true);
            rigidBody.current.setLinvel({ x: 0, y: 0, z: 0 }, true);
        }
    });

    const doDestroy = () => {
        if (destroyedRef.current) return; // 防止重复触发
        destroyedRef.current = true;
        addExperience(2);
        window.ultimateChargeAdd = (window.ultimateChargeAdd || 0) + 0.1;
        // 清除雷达位置
        if (window.npcPositions) delete window.npcPositions[id];
        onDestroy(id);
    };

    const onCollision = useCallback((e) => {
        const other = e.other?.rigidBodyObject;
        if (other?.userData?.type === 'player') {
            if (window.dashActive || window.shieldActive || window.rageActive || window.goldenShieldActive) {
                doDestroy();
            } else {
                takeDamage(2);
                doDestroy();
            }
        }
    }, []);

    return (
        <RigidBody
            ref={rigidBody}
            position={stablePosition}
            colliders="ball"
            onCollisionEnter={onCollision}
            userData={{ type: 'enemy_npc', level }}
            linearDamping={0.5}
        >
            {level >= 3 ? (
                <Trail width={2} length={5} color="#ff0000" attenuation={(t) => t * t}>
                    <mesh ref={meshRef}>
                        <sphereGeometry args={[radius, 16, 16]} />
                        <meshStandardMaterial
                            color="#ff2020"
                            emissive="#ff0000"
                            emissiveIntensity={3}
                            toneMapped={false}
                        />
                    </mesh>
                </Trail>
            ) : (
                <mesh ref={meshRef}>
                    <sphereGeometry args={[radius, 16, 16]} />
                    <meshStandardMaterial
                        color="#ff2020"
                        emissive="#ff0000"
                        emissiveIntensity={2}
                        toneMapped={false}
                    />
                </mesh>
            )}
        </RigidBody>
    );
};

export const HostileNPCs = () => {
    const { level: playerLevel, playerPosRef } = useGame();
    const [npcs, setNpcs] = useState([]);
    const npcIdCounter = useRef(100);

    const getWeightedLevel = useCallback((pLevel) => {
        const choices = [];
        if (pLevel > 1) {
            for (let i = 0; i < 4; i++) choices.push(pLevel - 1);
        }
        for (let i = 0; i < 2; i++) choices.push(pLevel);
        if (pLevel < 5) {
            choices.push(pLevel + 1);
        }
        return choices[Math.floor(Math.random() * choices.length)];
    }, []);

    const createNPC = useCallback((center) => {
        const id = npcIdCounter.current++;
        const pos = randomPosInShell(center || { x: 0, y: 0, z: 0 });
        return {
            id,
            level: getWeightedLevel(playerLevel),
            position: pos
        };
    }, [playerLevel, getWeightedLevel]);

    useEffect(() => {
        if (playerLevel < 2) return;
        if (npcs.length === 0) {
            const center = playerPosRef?.current || { x: 0, y: 0, z: 0 };
            const initialNpcs = Array.from({ length: NPC_COUNT }).map(() => createNPC(center));
            setNpcs(initialNpcs);
        }
    }, [playerLevel, npcs.length, createNPC]);

    const handleNPCDestroy = useCallback((id) => {
        setNpcs(prev => prev.filter(npc => npc.id !== id));
        setTimeout(() => {
            setNpcs(prev => {
                if (prev.length >= NPC_COUNT) return prev;
                const center = playerPosRef?.current || { x: 0, y: 0, z: 0 };
                const pos = randomPosInShell(center);
                const newId = npcIdCounter.current++;
                return [...prev, {
                    id: newId,
                    level: getWeightedLevel(playerLevel),
                    position: pos
                }];
            });
        }, 2000);
    }, [playerLevel, getWeightedLevel]);

    // NPC 位置由各自在 useFrame 中写入 window.npcPositions

    if (playerLevel < 2) return null;

    return (
        <group>
            {npcs.map(npc => (
                <HostileNPC
                    key={npc.id}
                    id={npc.id}
                    initialLevel={npc.level}
                    initialPosition={npc.position}
                    onDestroy={handleNPCDestroy}
                />
            ))}
        </group>
    );
};
